from cProfile import label
from hashlib import new
import tkinter as tk
from tkinter import *
from tkcalendar import DateEntry
import pandas as pd
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import LassoLarsCV
from sklearn.linear_model import Ridge

from sklearn.model_selection import train_test_split
from sklearn import linear_model

from math import sqrt
from sklearn.metrics import mean_squared_error

import matplotlib.pyplot as plt

root=Tk()
root.title('Ứng dụng dự đoán giá nhà')

def plotchar():
    plt.figure(figsize=(5,10))
    plt.title('RMSE')
    plt.ylabel('RMSE')
    plt.bar('SVR', rmse_SVR)
    plt.bar('LCV', rmse_LCV)
    plt.bar('Ridge', rmse_ridge)
    plt.legend(['SVR', 'LCV', 'Ridge'])
    plt.show()


def predictSVR():
    df = pd.DataFrame()
    if (listRegions.get() ==  "Chọn Quận hoặc Huyện") :
        ResultPre['text'] = 'Chưa chọn Quận/Huyện'
        return -1
    if (listXa.get() ==  "Chọn xã hoặc phường") :
        ResultPre['text'] = 'Chưa chọn Phường/Xã'
        return -1
    if (listStreet.get() ==  "Chọn Đường hoặc Khu vực") :
        ResultPre['text'] = 'Chưa chọn Đường, khu vực'
        return -1
    if (Dt.get().isnumeric() == False):
        ResultPre['text'] = 'Diện tích phải là số'
        return -1
    if (Nvs.get().isnumeric() == False):
        ResultPre['text'] = 'Nhà vệ sinh phải là số'
        return -1
    if (floor.get().isnumeric() == False):
        ResultPre['text'] = 'Số tầng phải là số'
        return -1
    if (Room.get().isnumeric() == False):
        ResultPre['text'] = 'Số phòng phải là số'
        return -1
    if (listGiayto.get() ==  "Chọn Giấy tờ") :
        ResultPre['text'] = 'Phải chọn Giấy tờ'
        return -1
    df['Quận/Huyện'] = [listRegions.get()]
    df['Phường/Xã'] = [listXa.get()]
    df['Đường, khu vực'] = [listStreet.get()]
    df['Diện tích'] = [Dt.get()]
    df['Số tầng'] = [floor.get()]
    df['Số phòng'] = [Room.get()]
    df['Nhà vệ sinh'] = [Nvs.get()]
    df['Giấy tờ pháp lý'] = [listGiayto.get()]
    t = cal.get_date().strftime('%m/%d/%Y')
    t = t.split("/")
    df['Tháng'] = [t[0]]
    df['Năm'] = [t[2]]
    df['Diện tích'] = df['Diện tích'].astype(float)
    df['Số tầng'] = df['Số tầng'].astype(int)
    df['Số phòng'] = df['Số phòng'].astype(int)
    df['Nhà vệ sinh'] = df['Nhà vệ sinh'].astype(int)
    df['Tháng'] = df['Tháng'].astype(int)
    df['Năm'] = df['Năm'].astype(int)

    df['Quận/Huyện'] = df['Quận/Huyện'].map(quan_huyen_dict)
    df['Phường/Xã'] = df['Phường/Xã'].map(phuong_xa_dict)
    df['Đường, khu vực'] = df['Đường, khu vực'].map(duong_khuvuc_dict)
    df['Giấy tờ pháp lý'] = df['Giấy tờ pháp lý'].map(giayto_dict)

    res = str(regressorSVR.predict(df)).replace('[', '')
    res = res.replace(']', '')
    res1 = float(res) * 10**9
    ResultPre['text'] =  '{:20,.0f}'.format(int(res1)) + " VND" +  " [SVR]"

def predictLCV():
    df = pd.DataFrame()
    if (listRegions.get() ==  "Chọn Quận hoặc Huyện") :
        ResultPre['text'] = 'Chưa chọn Quận/Huyện'
        return -1
    if (listXa.get() ==  "Chọn xã hoặc phường") :
        ResultPre['text'] = 'Chưa chọn Phường/Xã'
        return -1
    if (listStreet.get() ==  "Chọn Đường hoặc Khu vực") :
        ResultPre['text'] = 'Chưa chọn Đường, khu vực'
        return -1
    if (Dt.get().isnumeric() == False):
        ResultPre['text'] = 'Diện tích phải là số'
        return -1
    if (Nvs.get().isnumeric() == False):
        ResultPre['text'] = 'Nhà vệ sinh phải là số'
        return -1
    if (floor.get().isnumeric() == False):
        ResultPre['text'] = 'Số tầng phải là số'
        return -1
    if (Room.get().isnumeric() == False):
        ResultPre['text'] = 'Số phòng phải là số'
        return -1
    if (listGiayto.get() ==  "Chọn Giấy tờ") :
        ResultPre['text'] = 'Phải chọn Giấy tờ'
        return -1
    df['Quận/Huyện'] = [listRegions.get()]
    df['Phường/Xã'] = [listXa.get()]
    df['Đường, khu vực'] = [listStreet.get()]
    df['Diện tích'] = [Dt.get()]
    df['Số tầng'] = [floor.get()]
    df['Số phòng'] = [Room.get()]
    df['Nhà vệ sinh'] = [Nvs.get()]
    df['Giấy tờ pháp lý'] = [listGiayto.get()]
    t = cal.get_date().strftime('%m/%d/%Y')
    t = t.split("/")
    df['Tháng'] = [t[0]]
    df['Năm'] = [t[2]]
    df['Diện tích'] = df['Diện tích'].astype(float)
    df['Số tầng'] = df['Số tầng'].astype(int)
    df['Số phòng'] = df['Số phòng'].astype(int)
    df['Nhà vệ sinh'] = df['Nhà vệ sinh'].astype(int)
    df['Tháng'] = df['Tháng'].astype(int)
    df['Năm'] = df['Năm'].astype(int)

    df['Quận/Huyện'] = df['Quận/Huyện'].map(quan_huyen_dict)
    df['Phường/Xã'] = df['Phường/Xã'].map(phuong_xa_dict)
    df['Đường, khu vực'] = df['Đường, khu vực'].map(duong_khuvuc_dict)
    df['Giấy tờ pháp lý'] = df['Giấy tờ pháp lý'].map(giayto_dict)

    res = str(regressorLCV.predict(df)).replace('[', '')
    res = res.replace(']', '')
    res1 = float(res) * 10**9
    ResultPre['text'] =  '{:20,.0f}'.format(int(res1)) + " VND" +  " [LCV]"
    
def predictRidge():
    df = pd.DataFrame()
    if (listRegions.get() ==  "Chọn Quận hoặc Huyện") :
        ResultPre['text'] = 'Chưa chọn Quận/Huyện'
        return -1
    if (listXa.get() ==  "Chọn xã hoặc phường") :
        ResultPre['text'] = 'Chưa chọn Phường/Xã'
        return -1
    if (listStreet.get() ==  "Chọn Đường hoặc Khu vực") :
        ResultPre['text'] = 'Chưa chọn Đường, khu vực'
        return -1
    if (Dt.get().isnumeric() == False):
        ResultPre['text'] = 'Diện tích phải là số'
        return -1
    if (Nvs.get().isnumeric() == False):
        ResultPre['text'] = 'Nhà vệ sinh phải là số'
        return -1
    if (floor.get().isnumeric() == False):
        ResultPre['text'] = 'Số tầng phải là số'
        return -1
    if (Room.get().isnumeric() == False):
        ResultPre['text'] = 'Số phòng phải là số'
        return -1
    if (listGiayto.get() ==  "Chọn Giấy tờ") :
        ResultPre['text'] = 'Phải chọn Giấy tờ'
        return -1
    df['Quận/Huyện'] = [listRegions.get()]
    df['Phường/Xã'] = [listXa.get()]
    df['Đường, khu vực'] = [listStreet.get()]
    df['Diện tích'] = [Dt.get()]
    df['Số tầng'] = [floor.get()]
    df['Số phòng'] = [Room.get()]
    df['Nhà vệ sinh'] = [Nvs.get()]
    df['Giấy tờ pháp lý'] = [listGiayto.get()]
    t = cal.get_date().strftime('%m/%d/%Y')
    t = t.split("/")
    df['Tháng'] = [t[0]]
    df['Năm'] = [t[2]]
    df['Diện tích'] = df['Diện tích'].astype(float)
    df['Số tầng'] = df['Số tầng'].astype(int)
    df['Số phòng'] = df['Số phòng'].astype(int)
    df['Nhà vệ sinh'] = df['Nhà vệ sinh'].astype(int)
    df['Tháng'] = df['Tháng'].astype(int)
    df['Năm'] = df['Năm'].astype(int)

    df['Quận/Huyện'] = df['Quận/Huyện'].map(quan_huyen_dict)
    df['Phường/Xã'] = df['Phường/Xã'].map(phuong_xa_dict)
    df['Đường, khu vực'] = df['Đường, khu vực'].map(duong_khuvuc_dict)
    df['Giấy tờ pháp lý'] = df['Giấy tờ pháp lý'].map(giayto_dict)

    res = str(clf.predict(df)).replace('[', '')
    res = res.replace(']', '')
    res1 = float(res) * 10**9
    ResultPre['text'] =  '{:20,.0f}'.format(int(res1)) + " VND" +  " [Ridge]"

data = pd.read_csv('Data_Preprocessing.csv')
data2 = data.copy()
quan_huyen=data.groupby(['Quận/Huyện'],as_index=False).mean()
quan_huyen['row_num'] = quan_huyen.reset_index().index
quan_huyen_dict=quan_huyen[['Quận/Huyện','row_num']]
quan_huyen_dict=quan_huyen_dict.set_index('Quận/Huyện').T.to_dict('index')
quan_huyen_dict=quan_huyen_dict['row_num']

phuong_xa=data.groupby(['Phường/Xã'],as_index=False).mean()
phuong_xa['row_num'] = phuong_xa.reset_index().index
phuong_xa_dict=phuong_xa[['Phường/Xã','row_num']]
phuong_xa_dict=phuong_xa_dict.set_index('Phường/Xã').T.to_dict('index')
phuong_xa_dict=phuong_xa_dict['row_num']

duong_khuvuc=data.groupby(['Đường, khu vực'],as_index=False).mean()
duong_khuvuc['row_num'] = duong_khuvuc.reset_index().index
duong_khuvuc_dict=duong_khuvuc[['Đường, khu vực','row_num']]
duong_khuvuc_dict=duong_khuvuc_dict.set_index('Đường, khu vực').T.to_dict('index')
duong_khuvuc_dict=duong_khuvuc_dict['row_num']

giayto=data.groupby(['Giấy tờ pháp lý'],as_index=False).mean()
giayto['row_num'] = giayto.reset_index().index
giayto_dict=giayto[['Giấy tờ pháp lý','row_num']]
giayto_dict=giayto_dict.set_index('Giấy tờ pháp lý').T.to_dict('index')
giayto_dict=giayto_dict['row_num']

data['Quận/Huyện'] = data['Quận/Huyện'].map(quan_huyen_dict)
data['Phường/Xã'] = data['Phường/Xã'].map(phuong_xa_dict)
data['Đường, khu vực'] = data['Đường, khu vực'].map(duong_khuvuc_dict)
data['Giấy tờ pháp lý'] = data['Giấy tờ pháp lý'].map(giayto_dict)

x = data[['Quận/Huyện','Phường/Xã','Đường, khu vực','Diện tích','Số tầng','Số phòng','Nhà vệ sinh','Giấy tờ pháp lý','Tháng','Năm']]
y = data['Giá']
X_train, X_test, y_train, y_test= train_test_split(x, y, test_size = 0.3, random_state = 42)

#SVR
regressorSVR = SVR(kernel='rbf')
regressorSVR.fit(X_train,y_train)
y_pred = regressorSVR.predict(X_test)
rmse_SVR = sqrt(mean_squared_error(y_test,y_pred))

#LCV
regressorLCV = LassoLarsCV(cv=5, normalize=False).fit(X_train,y_train)
y_pred = regressorLCV.predict(X_test)
rmse_LCV = sqrt(mean_squared_error(y_test,y_pred))

#Ridge
clf = Ridge(alpha=1.0)
clf.fit(X_train,y_train)
y_pred = clf.predict(X_test)
rmse_ridge = sqrt(mean_squared_error(y_test,y_pred))


canvas= tk.Canvas(root,height=700,width=900,bg="#263D42")
canvas.pack()


frame=tk.Frame(root, bg="#d8d8d8")
frame.place(relwidth=0.8,relheight=0.8,relx=0.1,rely=0.1)


Tieude=Label(root,text="Ứng dụng dự đoán giá nhà",font="time 18 bold",bg="#d8d8d8",)
Tieude.place(relx=0.35,rely=0.02)
#Nút predict 1
predict= tk.Button(root,text="Prediction SVR",padx=10,pady=5,fg="white",bg="#263D42",command=predictSVR).pack()
#Nút predict 2
predict2= tk.Button(root,text="Prediction LCV",padx=10,pady=5,fg="white",bg="#263D42",command=predictLCV).place(relx=0.31,rely=0.912)
#Nút predict 3
predict3= tk.Button(root,text="Prediction Ridge",padx=10,pady=5,fg="white",bg="#263D42",command=predictRidge).place(relx=0.57,rely=0.912)
#Nút hiển thị biểu đồ
plot= tk.Button(root,text="Plot",padx=10,pady=5,fg="white",bg="#263D42",command=plotchar).pack()
#Combobox của Quận/Huyện
lists1=data2['Quận/Huyện'].sort_values().unique()
lists1 = list(lists1)
listRegions= StringVar(root)
listRegions.set("Chọn Quận hoặc Huyện")
menu=OptionMenu(root,listRegions,*lists1)
menu.place(relx=0.42,rely=0.12,relwidth=0.2,relheight=0.04)
District=Label(root,text="Quận/Huyện",font="time 14 bold",bg="#d8d8d8",)
District.place(relx=0.23,rely=0.12)

#Combobox của Xã/Phường
lists2=data2['Phường/Xã'].sort_values().unique()
lists2 = list(lists2)
listXa= StringVar(root)
listXa.set("Chọn xã hoặc phường")
menu2=OptionMenu(root,listXa,*lists2)
menu2.place(relx=0.42,rely=0.19,relwidth=0.2,relheight=0.04)
Xa=Label(root,text="Xã/Phường",font="time 14 bold",bg="#d8d8d8",)
Xa.place(relx=0.23,rely=0.19)

#Combobox của Đường/Khu vực
lists3=data2['Đường, khu vực'].sort_values().unique()
lists3 = list(lists3)
listStreet= StringVar(root)
listStreet.set("Chọn Đường hoặc Khu vực")
menu3=OptionMenu(root,listStreet,*lists3)
menu3.place(relx=0.42,rely=0.26,relwidth=0.2,relheight=0.04)
Street=Label(root,text="Đường/Khu vực",font="time 14 bold",bg="#d8d8d8",)
Street.place(relx=0.23,rely=0.26)

#EntryDate
Date=Label(root,text="Ngày đăng",font="time 14 bold",bg="#d8d8d8",)
Date.place(relx=0.23,rely=0.32)
cal=DateEntry(root,selectmode='day',height=20)
cal.place(relx=0.42,rely=0.329)

#Dien tich
Area=Label(root,text="Diện tích(m2)",font="time 14 bold",bg="#d8d8d8",)
Area.place(relx=0.23,rely=0.39)
Dt=Entry(root,width=50)
Dt.place(relx=0.42,rely=0.389,relwidth=0.2,relheight=0.04)


#So nha ve sinh
Nhavesinh=Label(root,text="Nhà vệ sinh",font="time 14 bold",bg="#d8d8d8",)
Nhavesinh.place(relx=0.23,rely=0.459)
Nvs=Entry(root,width=50)
Nvs.place(relx=0.42,rely=0.459,relwidth=0.2,relheight=0.04)

#So tang
Tang=Label(root,text="Số tầng",font="time 14 bold",bg="#d8d8d8",)
Tang.place(relx=0.23,rely=0.529)
floor=Entry(root,width=50)
floor.place(relx=0.42,rely=0.529,relwidth=0.2,relheight=0.04)

#So phong
Phong=Label(root,text="Số phòng",font="time 14 bold",bg="#d8d8d8",)
Phong.place(relx=0.23,rely=0.599)
Room=Entry(root,width=50)
Room.place(relx=0.42,rely=0.599,relwidth=0.2,relheight=0.04)

#Giay to phap ly
lists5=data2['Giấy tờ pháp lý'].sort_values().unique()
listGiayto= StringVar(root)
listGiayto.set("Chọn Giấy tờ")
menu5=OptionMenu(root,listGiayto,*lists5)
menu5.place(relx=0.42,rely=0.669,relwidth=0.2,relheight=0.04)
Giayto=Label(root,text="Giấy tờ",font="time 14 bold",bg="#d8d8d8",)
Giayto.place(relx=0.23,rely=0.669)


#Result
Result=Label(root,text="Kết quả dự đoán:",font="time 14 bold",bg="#d8d8d8",)
Result.place(relx=0.23,rely=0.739)
ResultPre=Label(root,text="",font="time 14 bold italic",bg="#ffff00")
ResultPre.place(relx=0.42,rely=0.739)

root.mainloop()